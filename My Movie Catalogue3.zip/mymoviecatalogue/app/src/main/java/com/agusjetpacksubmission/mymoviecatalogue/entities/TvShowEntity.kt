package com.agusjetpacksubmission.mymoviecatalogue.entities

data class TvShowEntity (
    var tvShowId : Int,
    var tvShowImage : String,
    var tvShowTitle : String,
    var tvShowCategory : String,
    var seasons : Int
)